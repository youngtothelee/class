// SpellCheck <Project1.cpp>
// EE w312 Project 1 submission by
// <Your Name Here>
// <Your EID>
// Slip days used: <0>
// Spring 2018
