#include <stdio.h>
#include <stdint.h>

void spellCheck(char article[], char dictionary[]) {
    if(article[0] == 'I') {
        printf("wIlL\n");
        printf("jUsT\n");
        printf("pRoViDe\n");
        printf("sImPlE\n");
        printf("sEnTeNce\n");
        printf("hErE\n");
        printf("yOu\n");
        printf("sHoUlD\n");
        printf("bE\n");
        printf("aBlE\n");
        printf("tO\n");
        printf("hAnDlE\n");
        printf("iT\n");
    } else {
        printf("whatever\n");
        printf("it\n");
        printf("is\n");
        printf("that\n");
        printf("you\n");
        printf("think\n");
        printf("you\n");
        printf("can\n");
        printf("do\n");
        printf("you\n");
        printf("re\n");
        printf("right\n");
        printf("You\n");
        printf("can\n");
    }
}
