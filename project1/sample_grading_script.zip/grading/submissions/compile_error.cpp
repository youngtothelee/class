#include <stdio.h>
#include <stdint.h>

void spellCheck(char article[], char dictionary[]) {
