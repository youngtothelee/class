#include <stdio.h>
#include <stdint.h>

void spellCheck(char article[], char dictionary[]) {
    printf("wIlL\n");
    printf("jUsT\n");
    printf("pRoViDe\n");
    printf("sImPlE\n");
    printf("sEnTeNce\n");
    printf("hErE\n");
    printf("yOu\n");
    printf("sHoUlD\n");
    printf("bE\n");
    printf("aBlE\n");
    printf("tO\n");
    printf("hAnDlE\n");
    printf("iT\n");
}
